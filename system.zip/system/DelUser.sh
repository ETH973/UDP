#!/bin/bash

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
ENDCOLOR="\e[0m"

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games/

clear
#banner
echo -e " ██████████████████████████████████████████████████ " | lolcat
echo -e " █▄─▄▄─█─▄─▄─█─█─█░▄▄░█▄▄▄░█▄▄▄░███─▄▄▄▄█─▄▄▄▄█─█─█ " | lolcat
echo -e " ██─▄█▀███─███─▄─█▄▄▄░███░███▄▄░███▄▄▄▄─█▄▄▄▄─█─▄─█ " | lolcat
echo -e " ▀▄▄▄▄▄▀▀▄▄▄▀▀▄▀▄▀▄▄▄▄▀▀▄██▀▄▄▄▄▀▀▀▄▄▄▄▄▀▄▄▄▄▄▀▄▀▄▀ " | lolcat

echo ""
echo ""
echo ""
allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)
echo -e "${GREEN}$allusers${ENDCOLOR}"
echo""
echo""

#deluser
echo -ne "${YELLOW}Nombre de usuario a eliminar: "; read username
while true; do
    read -p "¿Quieres eliminar el usuario $username ? (S/N) " sn
    case $yn in
        [Ss]* ) userdel $username && echo "" && echo -e "${RED}Usuario $username eliminado ${ENDCOLOR}" || echo -e "${RED}Error al eliminar el usuario  $username ${ENDCOLOR}"; break;;
        [Nn]* ) echo -e "${RED}\nEliminar usuario cancelado.${ENDCOLOR}"&&break;;
        * ) echo "Eliminar cancelado.";;
    esac
done

echo -e "\nEnter para regresar al menu"; read
udp
