#!/bin/bash

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[34m"
ENDCOLOR="\e[0m"

spinner()
{
    #Loading spinner
    local pid=$!
    local delay=0.75
    local spinstr='|/-\'
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

remove_script()
{
    systemctl stop udp-custom
    rm -rf /root/udp
    rm -rf /etc/ETH973
    systemctl daemon-reload
    rm -f /usr/local/bin/udp
    sed -i ':a;N;$!ba;s/\n\/bin\/false//g' /etc/shells
}

remove_confirm()
{
echo -ne "${RED}● Removiendo Script       ..."
remove_script >/dev/null 2>&1 &
spinner
echo -ne "\tdone"
echo -e "${ENDCOLOR}"
}
echo " Gracias por usar este script :D"
echo ""
echo "Creador ETH973"
clear
while true; do
    read -p "¿Quieres eliminar el script? (S/N) " sn
    case $sn in
        [Ss]* ) remove_confirm;echo -e "Eliminación completa. Presione Enter para salir";read;break;;
        [Nn]* ) echo -e "${RED}Eliminación cancelada!. Presione Enter para volver al menú principal${ENDCOLOR}";read;udp;break;;
        * ) echo "Responda sí o no.";;
    esac
done
