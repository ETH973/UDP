#!/bin/bash

GREEN="\e[32m"
ENDCOLOR="\e[0m"

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games/

clear
echo -e " ██████████████████████████████████████████████████ " | lolcat
echo -e " █▄─▄▄─█─▄─▄─█─█─█░▄▄░█▄▄▄░█▄▄▄░███─▄▄▄▄█─▄▄▄▄█─█─█ " | lolcat
echo -e " ██─▄█▀███─███─▄─█▄▄▄░███░███▄▄░███▄▄▄▄─█▄▄▄▄─█─▄─█ " | lolcat
echo -e " ▀▄▄▄▄▄▀▀▄▄▄▀▀▄▀▄▀▄▄▄▄▀▀▄██▀▄▄▄▄▀▀▀▄▄▄▄▄▀▄▄▄▄▄▀▄▀▄▀ " | lolcat
echo ""
echo ""
allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)
echo -e "${GREEN}$allusers${ENDCOLOR}"

echo -e "\nEnter para regresar al menu"; read
udp
