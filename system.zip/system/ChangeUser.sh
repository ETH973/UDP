#!/bin/bash

#font colors
IP=$(curl -s ifconfig.me)
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
ENDCOLOR="\e[0m"

s_ip=$(wget -qO- https://ipecho.net/plain ; echo)

clear
echo -e " ██████████████████████████████████████████████████ " | lolcat
echo -e " █▄─▄▄─█─▄─▄─█─█─█░▄▄░█▄▄▄░█▄▄▄░███─▄▄▄▄█─▄▄▄▄█─█─█ " | lolcat
echo -e " ██─▄█▀███─███─▄─█▄▄▄░███░███▄▄░███▄▄▄▄─█▄▄▄▄─█─▄─█ " | lolcat
echo -e " ▀▄▄▄▄▄▀▀▄▄▄▀▀▄▀▄▀▄▄▄▄▀▀▄██▀▄▄▄▄▀▀▀▄▄▄▄▄▀▄▄▄▄▄▀▄▀▄▀ " | lolcat
echo ""
#echo -e "                                   Modificador ETH973"
#add users
echo ""
echo ""
echo -ne "${YELLOW}Nombre de usuario: "; read username
while true; do
    read -p "Desea generar contraseña automaticamente ? (S/N) " sn
    case $sn in
        [Ss]* ) password=$(< /dev/urandom tr -dc _A-Z-a-z-0-9 | head -c${1:-9};echo;); break;;
        [Nn]* ) echo -ne "Ingresa la contraseña (utilice una contraseña segura): "; read password; break;;
        * ) echo "Por favor responda sí o no.";;
    esac
done
echo -ne "Nueva duracion: ";read nod
exd=$(date +%F  -d "$nod days")
chage -E $exd $username && echo "$username:$password" | chpasswd &&
clear &&
echo -e  "${YELLOW} Cambiando detalles de usuario, por favor espere.."
sleep 3
clear
echo -e " ██████████████████████████████████████████████████ " | lolcat
echo -e " █▄─▄▄─█─▄─▄─█─█─█░▄▄░█▄▄▄░█▄▄▄░███─▄▄▄▄█─▄▄▄▄█─█─█ " | lolcat
echo -e " ██─▄█▀███─███─▄─█▄▄▄░███░███▄▄░███▄▄▄▄─█▄▄▄▄─█─▄─█ " | lolcat
echo -e " ▀▄▄▄▄▄▀▀▄▄▄▀▀▄▀▄▀▄▄▄▄▀▀▄██▀▄▄▄▄▀▀▀▄▄▄▄▄▀▄▄▄▄▄▀▄▀▄▀ " | lolcat

echo -e "========== Cuenta UDP Custom SSH =========="
echo -e ""
echo -e "${GREEN}\n• Direccion IP : ${YELLOW}$s_ip"
echo -e "${GREEN}\n• Usuario :${YELLOW} $username"
echo -e "${GREEN}\n• Contraseña :${YELLOW} $password"
echo -e "${GREEN}\n• Dias de duracion :${YELLOW} $exd"
echo -e "${GREEN}\n• Limite de usuarios :${YELLOW} $maxlogins${ENDCOLOR}"
#echo -e "======================================="
echo -e "========== Http Custom UDP ==========="
echo -e "$s_ip:1-65535@$username:$password"
echo -e "======================================="
echo -e " >> Creador Telegram : @ETH973"
echo -e " >> Usuario en Github : @ETH973"
echo -e "======================================="
#echo -e "${RED}\nError al agresar el usuario $username intenta de nuevo"
echo ""

#return to panel

echo -e "\nEnter para regresar al menu"; read
udp
