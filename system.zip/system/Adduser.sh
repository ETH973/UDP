#!/bin/bash

#font colors
IP=$(cat /etc/IP)
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
ENDCOLOR="\e[0m"

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games/

s_ip=$(wget -qO- https://ipecho.net/plain ; echo)

clear

#add users
echo -e " ██████████████████████████████████████████████████ " | lolcat
echo -e " █▄─▄▄─█─▄─▄─█─█─█░▄▄░█▄▄▄░█▄▄▄░███─▄▄▄▄█─▄▄▄▄█─█─█ " | lolcat
echo -e " ██─▄█▀███─███─▄─█▄▄▄░███░███▄▄░███▄▄▄▄─█▄▄▄▄─█─▄─█ " | lolcat
echo -e " ▀▄▄▄▄▄▀▀▄▄▄▀▀▄▀▄▀▄▄▄▄▀▀▄██▀▄▄▄▄▀▀▀▄▄▄▄▄▀▄▄▄▄▄▀▄▀▄▀ " | lolcat  
echo ""
echo -ne "${YELLOW}Nombre de usuario: "; read username
while true; do
    read -p "Generar contraseña? (S/N) " sn
    case $sn in
        [Ss]* ) password=$(< /dev/urandom tr -dc _A-Z-a-z-0-9 | head -c${1:-9};echo;); break;;
        [Nn]* ) echo -ne "Contraseña: "; read password; break;;
        * ) echo "Eliminar cancelado.";;
    esac
done
echo -ne "Días de duración : ";read nod
exd=$(date +%F  -d "$nod days")

read -p "Limite de conexiones:" maxlogins
echo "$username  hard  maxlogins ${maxlogins}" >/etc/security/limits.d/"$username"

sudo sysctl -w net.ipv6.conf.all.disable_ipv6=1
sudo sysctl -w net.ipv6.conf.default.disable_ipv6=1
sudo sysctl -w net.ipv6.conf.lo.disable_ipv6=1

useradd -e $exd -M -N -s /bin/false $username && echo "$username:$password" | chpasswd &&
clear &&
echo -e  "${YELLOW} Creando usuario por favor espere.."
sleep 3
clear
echo -e " ██████████████████████████████████████████████████ " | lolcat
echo -e " █▄─▄▄─█─▄─▄─█─█─█░▄▄░█▄▄▄░█▄▄▄░███─▄▄▄▄█─▄▄▄▄█─█─█ " | lolcat
echo -e " ██─▄█▀███─███─▄─█▄▄▄░███░███▄▄░███▄▄▄▄─█▄▄▄▄─█─▄─█ " | lolcat
echo -e " ▀▄▄▄▄▄▀▀▄▄▄▀▀▄▀▄▀▄▄▄▄▀▀▄██▀▄▄▄▄▀▀▀▄▄▄▄▄▀▄▄▄▄▄▀▄▀▄▀ " | lolcat
echo ""
echo ""
echo -e "========== Cuenta UDP Custom SSH =========="
echo -e "${GREEN}\n• Direccion IP:${YELLOW}$s_ip"
echo -e "${GREEN}\n• Usuario:${YELLOW} $username"
echo -e "${GREEN}\n• Contraseña:${YELLOW} $password"
echo -e "${GREEN}\n• Dias de duracion:${YELLOW} $exd"
echo -e "${GREEN}\n• Limite de usuarios:${YELLOW} $maxlogins${ENDCOLOR}"
#echo -e "======================================="
#echo -e ""
echo -e "================= Puerto ================="
echo -e ""
echo -e "${GREEN}\n• Badvpn: ${YELLOW}1-65535${ENDCOLOR}"
echo -e ""
echo -e "========== Http Custom UDP ==========="
echo -e "$s_ip:1-65535@$username:$password"
echo -e "======================================="
echo""
echo -e " >> Modificador Telegram: @ETH973"
echo -e " >> Usuario en Github: @ETH973"
echo""
echo -e "======================================="
#echo -e "${RED}\nError al agregar el usuario $username intenta de nuevo."
echo ""
echo ""

#return to panel

echo -e "\nEnter para regresar al menu"; read
udp
